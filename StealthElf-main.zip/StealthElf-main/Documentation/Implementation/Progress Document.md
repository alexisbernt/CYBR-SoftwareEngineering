## Progress Document
* Main
  * main - Complete
  * showMenu - Complete
  * validateFileLocation - Complete
  * manualSelection - Complete
  * runningCheck - Complete
 
* Backup
  * copyFile - Incomplete
 
* Preset
  * checkPreset - Incomplete
  * newPreset- Incomplete
  * loadPreset - Incomplete
  * deletePreset - Incomplete
