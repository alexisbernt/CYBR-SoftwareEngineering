## 4.1 - The Basics
- **Team Members and Roles**: Carissa Kelley (Programmer), Alexis Bernthal (Security), Huigwnag Cha (Documentarian), Jordan Schnell (Team Lead)
- **Idea**: Backup Software for Windows Computers

