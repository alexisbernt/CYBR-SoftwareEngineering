Sources used for understanding Java (so I could add security): 
https://www.w3schools.com/java/java_intro.asp
https://www.geeksforgeeks.org/scanner-nextint-method-in-java-with-examples/
